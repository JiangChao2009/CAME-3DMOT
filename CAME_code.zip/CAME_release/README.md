## CAME: Consistency-Aware Multisensor Measurement and State Estimation for Real-Time 3D Object Tracking

## Introduction

Accurate and temporally consistent measurement of surrounding objects is essential in autonomous driving. From an instrumentation and measurement (I\&M) perspective, 3D multi-object tracking can be viewed as repeated multisensor state estimation whose quality is limited by cross-sensor inconsistencies, ego-motion–induced distortions, and coarse geometric metrics for association. This paper presents \textbf{CAME}, a consistency-aware multisensor measurement and state-estimation framework for real-time 3D object tracking. CAME integrates three lightweight components. First, a center-plane adaptive LiDAR--camera projection model corrects pose-dependent width expansion and enables decision-level fusion with calibrated semantics. Second, an IMU/GPS-driven ego-pose chain based on an error-state Kalman filter provides motion-consistent poses for ego-motion compensation. Third, a two-stage association scheme combines distance gating with a rotational geometric distance IoU (RGDIoU) that couples volumetric overlap, normalized center distance, and yaw penalties to measure 3D spatial consistency. On KITTI, CAME improves sAMOTA by more than 13 points and achieves a HOTA of 50.83% while running at approximately 140~FPS; on nuScenes, it attains an AMOTA of 0.800 and substantially reduces identity switches compared with strong baselines. These results show that the proposed consistency-aware framework provides a practical I\&M solution that balances accuracy, robustness, and efficiency for real-time 3D object state estimation.

## Installation

This code has been tested on the following combination of major prerequisites. Please ensure compatibility before proceeding.

* Operating System: Ubuntu 20.04

 * Python Version: 3.8

This code requires the following packages:

1. scikit-learn==0.19.2
2. filterpy==1.4.5
3. numba==0.58.1
4. matplotlib==3.5.3
5. pillow==10.3.0
6. opencv-python==4.9.0.80
7. glob2==0.6
8. PyYAML==6.0.2
9. easydict==1.10
10. llvmlite==0.41.1
11. wheel==0.40.0
12. nuscenes-devkit==1.1.9
13. motmetrics<=1.1.3
14. pandas>=0.24


## Dataset Preparation

* KITTI Dataset: Please download the official KITTI multi-object tracking dataset(http://www.cvlibs.net/datasets/kitti/eval_tracking.php), including left color images, velodyne point clouds, GPS/IMU data, training labels, and camera calibration data. Uncompress the dataset and place it under the ./data/KITTI folder (either as a hard copy or soft symbolic link).

* nuScenes Dataset: Please download the official nuScenes full dataset (v1.0) (https://www.nuscenes.org/download).Uncompress the dataset and place it under the ./data/nuScenes/data folder (either as a hard copy or soft symbolic link).

Directory structure for both datasets:

```
CAME
├── configs
│   ├── KITTI.yml
│   └── nuScenes.yml
├── coupled_state_filtering.py
├── data
│   ├── __init__.py
│   ├── KITTI
│   │   ├── calib
│   │   │   ├── testing
│   │   │   └── training
│   │   ├── detection
│   │   │   ├── F_Cyclist_val
│   │   │   ├── F_Pedestrian_test
│   │   │   └── F_Pedestrian_val
│   │   ├── image
│   │   │   ├── testing
│   │   │   │   └── image_02 -> /home/DataSets/KITTI/Track/testing/image_02
│   │   │   └── training
│   │   │       └── image_02 -> /home/DataSets/KITTI/Track/training/image_02
│   │   ├── __init__.py
│   │   ├── oxts
│   │   │   ├── testing
│   │   │   └── training
│   │   └── tracking
│   │       ├── testing -> /home/DataSets/KITTI/Track/kitti/testing
│   │       └── training -> /home/DataSets/KITTI/Track/kitti/training
│   └── nuScenes
│       ├── data
│       │   ├── maps
│       │   ├── produced
│       │   │   └── results
│       │   │       └── detection
│       │   │           └── detname
│       │   │               └── results_val.json
│       │   ├── samples
│       │   ├── sweeps
│       │   ├── v1.0-mini
│       │   ├── v1.0-test
│       │   └── v1.0-trainval 
│       ├── detection
│       └── nuKITTI
├── evaluate
│   ├── __init__.py
│   ├── KITTI
│   │   ├── evaluate.py
│   │   ├── __init__.py
│   │   ├── label
│   │   ├── mailpy.py
│   │   └── munkres.py
│   └── nuScenes
│       ├── evaluate.py
│       ├── evaluate_quick.py
│       ├── export_kitti.py
│       ├── __init__.py
│       └── requirements.txt
├── CAME.py
├── model.py
├── projection_and_correction.cpython-38-x86_64-linux-gnu.so
├── README.md
├── requirements.txt
├── results
│   └── KITTI
│       ├── F_test_result
│       │   └── data
│       ├── F_val_result
│       │   └── data
│       └── log
└── RGDIOU.py
```


## KITTI
## export PYTHONPATH=${PYTHONPATH}:~/TIM/CAME_release

## 3D Object Detection

For convenience, we provide the 3D detection results on the KITTI MOT dataset at ./data/KITTI/detection. Our detection results follow the format of the KITTI 3D Object Detection Challenge  (detailed format definition can be found here: http://www.cvlibs.net/datasets/kitti/eval_object.php?obj_benchmark=3d), with the order switched.

Example of detection:


Frame |       Type     |   2D BBOX (x1, y1, x2, y2)  | Score |    3D BBOX (h, w, l, x, y, z, rot_y)      | Alpha  | 
------|:--------------:|:---------------------------:|:-----:|:-----------------------------------------:|:------:|
 25   | 1 (pedestrian) | 622.1, 171.5, 635.9, 208.2  | 0.471 | 1.72, 0.80, 0.91, 0.84, 1.38, 34.6, -1.62 | -1.645 | 
 

## 3D Multi-Object Tracking

To run our tracker on the KITTI MOT dataset with the provided detections:

```
python3 CAME.py --dataset KITTI --split val   --category pedestrian --para 0.0 0.0 0.0 0.7 0.5 0
```

In detail, running above command will generate a folder named "F_val(or test)_result" that includes results for the specified categories. Under each result folder, "./data" subfolders are used for MOT evaluation, which follow the format of the KITTI Multi-Object Tracking Challenge (format definition can be found in the tracking development toolkit here: http://www.cvlibs.net/datasets/kitti/eval_tracking.php). 


### 3D MOT Evaluation on KITTI MOT Validation Set

To reproduce the quantitative 3D MOT results of our tracking system on the KITTI MOT validation set with a threshold of 0.25 3D IoU, please execute the following command:
```
python3 evaluate/KITTI/evaluate.py F_val_result 3D 0.25 pedestrian
```
The results should closely match the ones provided below, with the only variation being the FPS, which may differ across individual machines. The overall performance is averaged over three categories for sAMOTA, MOTA, and MOTP, and summed over the same categories for IDS, FRAG, FP, and FN. Please ensure that the CPU is not heavily occupied by other tasks, as this could affect the speed and result in discrepancies from the reported FPS.

#### (KITTI val set)

The results evaluated with the 0.25 3D IoU threshold, min_hits = 0, and max_age = 3 should be as follows:


 Category       | sAMOTA |  MOTA  |  MOTP  | IDS | FRAG |  FP  |  FN  |  FPS 
--------------- |:------:|:------:|:------:|:---:|:----:|:----:|:----:|:-----:
 *Pedestrian*   | 94.04  | 82.82  | 73.18  |  29 |  52  | 1181 |  471 | 346.0




### 2D MOT Evaluation on KITTI MOT Validation Set

To reproduce the quantitative 2D MOT results of our 3D MOT system on the KITTI MOT validation set, execute the following command:

```
python3 evaluate/KITTI/evaluate.py F_val_result 2D 0.5 pedestrian
```

The results evaluated with the 0.5 2D IoU threshold, min_hits = 0, and max_age = 3 should be:


 Category       | sAMOTA |  MOTA  |  MOTP  | IDS | FRAG |  FP  |  FN  |  FPS 
--------------- |:------:|:------:|:------:|:---:|:----:|:----:|:----:|:----:|
 *Pedestrian*   | 87.01  | 74.50  |  73.28 | 170 | 360  | 1119 | 1207 | 346.0






### 2D MOT Evaluation on KITTI MOT Test Set

To run our tracker on the test set with the provided detections, one can simply run:
```
python3 CAME.py --dataset KITTI --split test   --category pedestrian --para 0.0 0.0 0.0 0.7 0.5 0
```
Then, the results will be saved to the "./results/KITTI/F_test_result" folder. 

Then, compress the folder below and upload to http://www.cvlibs.net/datasets/kitti/user_submit.php for KITTI 2D MOT evaluation. Note that KITTI does not release the ground truth labels to users, so we have to use the official KITTI 2D MOT evaluation server for evaluation, which does not include our new metrics.
```
./results/KITTI/F_test_result/data
```
The results should be similar to our entry on the KITTI 2D MOT leaderboard. 


 Category       |  HOTA  |  DetA  |  AssA  | DetRe | DetPr | AssRe | AssPr | LocA |
--------------- |:------:|:------:|:------:|:-----:|:-----:|:-----:|:-----:|:----:|
 *Pedestrian*   | 50.59  | 49.99  |  51.61 | 55.38 | 66.80 | 55.86 | 72.18 | 75.85|

Note that this performance is higher than reported in our original paper due to several improvements in the code.
 

## nuScenes

## 3D Object Detection

Before starting the 3D Multi-Object Tracking (MOT), please prepare the detection results from the nuScenes dataset and convert them to the following format:
 
Frame |       Type     |   2D BBOX (x1, y1, x2, y2)  | Score |    3D BBOX (h, w, l, x, y, z, rot_y)      | Alpha  | 
------|:--------------:|:---------------------------:|:-----:|:-----------------------------------------:|:------:|
 25   | 1 (pedestrian) | 622.1, 171.5, 635.9, 208.2  | 0.471 | 1.72, 0.80, 0.91, 0.84, 1.38, 34.6, -1.62 | -1.645 | 
 
## 3D Multi-Object Tracking

Once the data is properly prepared, running the CAME tracker on the nuScenes dataset is as simple as running it on KITTI. For instance, to run the tracker using the Megvii detections on the validation set, use the following command:
```
python3 CAME.py --dataset nuScenes --split val (or test)   --category pedestrian --para 0.0 0.0 0.0 0.7 0.5 0
```
The results for all categories will then be saved in the ./results/nuScenes/megvii_val_result folder, in a format similar to the KITTI tracking result format.

### 3D MOT Evaluation on the nuScenes Tracking Validation Set

To evaluate the 3D MOT results of our tracking system on the nuScenes tracking validation set, follow these steps:1. Convert the result format to the nuScenes tracking result format (https://www.nuscenes.org/tracking/?externalData=all&mapData=all&modalities=Any) using the provided script. 2. Then, run the official nuScenes MOT evaluation code (https://github.com/nutonomy/nuscenes-devkit/blob/master/python-sdk/nuscenes/eval/tracking/evaluate.py) . For simplicity, we have made a local copy of the evaluation code in this repository, please run:
```
python3 evaluate/nuScenes/export_kitti.py kitti_trk_result2nuscenes --result_name megvii_val_result --split val
python3 evaluate/nuScenes/evaluate.py --result_path ./results/nuScenes/megvii_val_result/results_val.json
```


### 3D MOT Evaluation on the nuScenes Tracking Test Set

To evaluate the 3D MOT results on the nuScenes tracking test set, please run:
```
python3 evaluate/nuScenes/export_kitti.py kitti_trk_result2nuscenes --result_name megvii_test_result --split test
```

Afterward, compress the result file located at ./results/nuScenes/megvii_test_result/results_test.json into a zip file and upload it to the official evaluation platform (https://eval.ai/web/challenges/challenge-page/476/submission) for nuScenes 3D MOT evaluation.

Please note that nuScenes does not release the ground truth labels to the public, so the evaluation must be done through the official nuScenes 3D MOT evaluation server. The results should be comparable to our submission on the nuScenes 3D MOT leaderboard, as shown below:

#### nuScenes test set

 Category     |  AMOTA |  MOTA  |  MOTP  | IDS | FRAG |  FP   |  FN
--------------|:------:|:------:|:------:|:---:|:----:|:-----:|:-----:
 *Pedestrian* | 0.808  | 0.675  | 0.358  | 311 | 134  | 6024  | 4720



