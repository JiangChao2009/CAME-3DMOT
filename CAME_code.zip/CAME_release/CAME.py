from __future__ import print_function
import matplotlib; matplotlib.use('Agg')
import yaml, os, numpy as np, os, time, sys, argparse
import glob
from easydict import EasyDict as edict
sys.path.append('./projection_and_correction.cpython-38-x86_64-linux-gnu.so') 
from projection_and_correction import vehicle_pose_estimation,load_detection_data, generate_saving_directory, retrieve_frame_detections, save_results, save_affinity
from model import CAMETRACK
from numba import jit
from typing import List, Tuple, Dict, Any
from collections import namedtuple
from RGDIOU import rotx,roty,rotz


def inverse_rigid_trans(Tr):
    """
    Computes the inverse of a rigid body transformation matrix (3x4, [R|t]).
    The inverse of the rigid transformation is given by:
        [R'|-R't; 0|1]

    Args:
        Tr (np.ndarray): 3x4 rigid transformation matrix [R|t].

    Returns:
        np.ndarray: 3x4 inverse transformation matrix.
    """
    inv_Tr = np.zeros_like(Tr)  # Initialize inverse matrix
    inv_Tr[0:3, 0:3] = np.transpose(Tr[0:3, 0:3])  # Transpose of rotation matrix
    inv_Tr[0:3, 3] = np.dot(-np.transpose(Tr[0:3, 0:3]), Tr[0:3, 3])  # Inverse translation
    return inv_Tr


def save_calib_file(transform, save_path):
    """
    Saves the calibration data to a file in a specific format.

    Args:
        transform (dict): Calibration data in a dictionary.
        save_path (str): Path to save the calibration file.
    """
    with open(save_path, "w") as calib_file:
        for key, val in transform.items():
            val = val.flatten()
            val_str = '%.12e' % val[0]  # Format the first value with scientific notation
            for v in val[1:]:
                val_str += ' %.12e' % v  # Append subsequent values
            calib_file.write('%s: %s\n' % (key, val_str))  # Write to file


class Calibration(object):
    """
    Calibration matrices and utility functions for transforming points
    between different coordinate systems (e.g., camera, lidar, reference).
    The transformations include rigid body transforms, projections, and
    other calibration utilities.

    Attributes:
        P (np.ndarray): Projection matrix from rect camera to image2 coordinate system.
        V2C (np.ndarray): Transformation matrix from Velodyne coordinate to camera reference.
        R0 (np.ndarray): Rotation matrix from reference camera to rect camera.
        I2V (np.ndarray): Transformation matrix from IMU to Velodyne.
        C2V (np.ndarray): Inverse of the transformation from Velodyne to camera reference.
        c_u, c_v, f_u, f_v (float): Camera intrinsics.
        b_x, b_y (float): Baseline shifts in the x and y directions.
    """

    def __init__(self, calib_filepath, from_video=False):
        """
        Initialize the Calibration object and load the calibration data from the specified file.

        Args:
            calib_filepath (str): Path to the calibration file.
            from_video (bool): Flag indicating whether calibration data is from a video.
        """
        if from_video:
            calibs = self.read_calib_from_video(calib_filepath)
        else:
            calibs = self.read_calib_file(calib_filepath)

        # Projection matrix from rect camera coordinate to image2 coordinate
        self.P = np.reshape(calibs['P2'], [3, 4])

        # Transformation from Velodyne coordinate to reference camera coordinate
        try:
            self.V2C = np.reshape(calibs['Tr_velo_to_cam'], [3, 4])
        except KeyError:
            self.V2C = np.reshape(calibs['Tr_velo_cam'], [3, 4])

        self.V2C_R = self.V2C[:3, :3]  # Rotation matrix
        self.V2C_T = self.V2C[:, 3]   # Translation vector
        self.C2V = inverse_rigid_trans(self.V2C)  # Inverse of the transformation

        # Rotation from reference camera coordinate to rect camera coordinate
        try:
            self.R0 = np.reshape(calibs['R0_rect'], [3, 3])
        except KeyError:
            self.R0 = np.reshape(calibs['R_rect'], [3, 3])

        # Transformation from IMU to Velodyne
        try:
            self.I2V = np.reshape(calibs['Tr_imu_to_velo'], [3, 4])
        except KeyError:
            self.I2V = np.reshape(calibs['Tr_imu_velo'], [3, 4])
        self.V2I = inverse_rigid_trans(self.I2V)

        # Camera intrinsics
        self.c_u = self.P[0, 2]
        self.c_v = self.P[1, 2]
        self.f_u = self.P[0, 0]
        self.f_v = self.P[1, 1]
        self.b_x = self.P[0, 3] / (-self.f_u)  # Baseline shift in x direction
        self.b_y = self.P[1, 3] / (-self.f_v)  # Baseline shift in y direction

    def read_calib_file(self, filepath):
        """
        Reads and parses the calibration file into a dictionary.

        Args:
            filepath (str): Path to the calibration file.

        Returns:
            dict: Parsed calibration data.
        """
        data = {}
        with open(filepath, 'r') as f:
            for line in f.readlines():
                line = line.rstrip()
                if len(line) == 0: continue
                key, value = line.split(':', 1)
                try:
                    data[key] = np.array([float(x) for x in value.split()])
                except ValueError:
                    pass
        return data

    def cart2hom(self, pts_3d):
        """
        Convert 3D Cartesian coordinates to homogeneous coordinates.

        Args:
            pts_3d (np.ndarray): Array of 3D Cartesian points.

        Returns:
            np.ndarray: Array of points in homogeneous coordinates.
        """
        n = pts_3d.shape[0]
        pts_3d_hom = np.hstack((pts_3d, np.ones((n, 1))))
        return pts_3d_hom

    # =========================== 
    # --------- 3d to 3d --------- 
    # =========================== 

    def imu_to_rect(self, pts_imu):
        """
        Convert IMU coordinates to rect camera coordinates.

        Args:
            pts_imu (np.ndarray): IMU points in 3D.

        Returns:
            np.ndarray: Corresponding points in rect camera coordinates.
        """
        pts_velo = self.imu_to_velo(pts_imu)
        pts_ref = self.project_velo_to_ref(pts_velo)
        return self.project_ref_to_rect(pts_ref)

    def imu_to_velo(self, pts_imu):
        """
        Convert IMU coordinates to Velodyne coordinates.

        Args:
            pts_imu (np.ndarray): IMU points in 3D.

        Returns:
            np.ndarray: Corresponding points in Velodyne coordinates.
        """
        pts_imu = self.cart2hom(pts_imu)  # Convert to homogeneous coordinates
        return np.dot(pts_imu, np.transpose(self.I2V))

    def velo_to_imu(self, pts_velo):
        """
        Convert Velodyne coordinates to IMU coordinates.

        Args:
            pts_velo (np.ndarray): Velodyne points in 3D.

        Returns:
            np.ndarray: Corresponding points in IMU coordinates.
        """
        pts_velo = self.cart2hom(pts_velo)  # Convert to homogeneous coordinates
        return np.dot(pts_velo, np.transpose(self.V2I))

    def project_velo_to_ref(self, pts_3d_velo):
        """
        Project Velodyne coordinates to reference camera coordinates.

        Args:
            pts_3d_velo (np.ndarray): Velodyne points in 3D.

        Returns:
            np.ndarray: Corresponding points in reference camera coordinates.
        """
        pts_3d_velo = self.cart2hom(pts_3d_velo)  # Convert to homogeneous coordinates
        return np.dot(pts_3d_velo, np.transpose(self.V2C))

    def project_ref_to_rect(self, pts_3d_ref):
        """
        Project reference camera coordinates to rect camera coordinates.

        Args:
            pts_3d_ref (np.ndarray): Points in reference camera coordinates.

        Returns:
            np.ndarray: Corresponding points in rect camera coordinates.
        """
        return np.transpose(np.dot(self.R0, np.transpose(pts_3d_ref)))

    def project_rect_to_velo(self, pts_3d_rect):
        """
        Project rect camera coordinates to Velodyne coordinates.

        Args:
            pts_3d_rect (np.ndarray): Points in rect camera coordinates.

        Returns:
            np.ndarray: Corresponding points in Velodyne coordinates.
        """
        pts_3d_ref = self.project_rect_to_ref(pts_3d_rect)
        return self.project_ref_to_velo(pts_3d_ref)

    def project_rect_to_ref(self, pts_3d_rect):
        """
        Project rect camera coordinates to reference camera coordinates.

        Args:
            pts_3d_rect (np.ndarray): Points in rect camera coordinates.

        Returns:
            np.ndarray: Corresponding points in reference camera coordinates.
        """
        return np.transpose(np.dot(np.linalg.inv(self.R0), np.transpose(pts_3d_rect)))

    def project_ref_to_velo(self, pts_3d_ref):
        """
        Project reference camera coordinates to Velodyne coordinates.

        Args:
            pts_3d_ref (np.ndarray): Points in reference camera coordinates.

        Returns:
            np.ndarray: Corresponding points in Velodyne coordinates.
        """
        pts_3d_ref = self.cart2hom(pts_3d_ref)  # Convert to homogeneous coordinates
        return np.dot(pts_3d_ref, np.transpose(self.C2V))

    def rect_to_imu(self, pts_rect):
        """
        Convert rect camera coordinates to IMU coordinates.

        Args:
            pts_rect (np.ndarray): Points in rect camera coordinates.

        Returns:
            np.ndarray: Corresponding points in IMU coordinates.
        """
        pts_velo = self.project_rect_to_velo(pts_rect)
        return self.velo_to_imu(pts_velo)


def load_oxts(oxts_file):
    """
    Load OXTS data from the given file and return the IMU poses.

    Args:
        oxts_file (str): Path to the OXTS data file.

    Returns:
        np.ndarray: IMU poses in the world frame.
    """
    ext = os.path.splitext(oxts_file)[-1]
    if ext == '.json':  # Loading for nuScenes-to-KITTI data
        with open(oxts_file, 'r') as file:
            imu_poses = json.load(file)
            imu_poses = np.array(imu_poses)
        return imu_poses

    # Extract the data from each OXTS packet per the KITTI data format
    from collections import namedtuple
    OxtsPacket = namedtuple('OxtsPacket',
                            'lat, lon, alt, roll, pitch, yaw, vn, ve, vf, vl, vu, '
                            'ax, ay, az, af, al, au, wx, wy, wz, wf, wl, wu, '
                            'pos_accuracy, vel_accuracy, navstat, numsats, posmode, '
                            'velmode, orimode')

    oxts_packets = []
    with open(oxts_file, 'r') as f:
        for line in f.readlines():
            line = line.split()
            line[:-5] = [float(x) for x in line[:-5]]
            line[-5:] = [int(float(x)) for x in line[-5:]]
            data = OxtsPacket(*line)
            oxts_packets.append(data)
    er = 6378137.  # Earth's radius in meters for Mercator projection.
    imu_poses = vehicle_pose_estimation(oxts_packets,er)  # Convert OXTS packets to poses in the world frame
    return imu_poses
 



# Argument parser for managing command-line parameters
def parse_args():
    parser = argparse.ArgumentParser(description='CAMETRACK')
    parser.add_argument('--dataset', type=str, default='nuScenes', help='KITTI, nuScenes')
    parser.add_argument('--split', type=str, default='', help='train, val, test')
    parser.add_argument('--det_name', type=str, default='', help='Detection name (e.g., pointrcnn)')
    parser.add_argument('--category', type=str, default='all', help='car, pedestrian, cyclist, all')
    parser.add_argument('--para', type=float, nargs=6, default=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], help='Displacement adjustments for bounding boxes')
    parser.add_argument('--PC', type=float, default=1, help='Enable correction module for 2D projections')
    parser.add_argument('--IOU_module', type=str, default='rgdiou_3d', help='Enable the IOU calculation module')

    return parser.parse_args()

# Configuration loading with YAML
def Config(filename):
    with open(filename, 'r') as listfile1, open(filename, 'r') as listfile2:
        cfg = edict(yaml.safe_load(listfile1))  # Dictionary from YAML
        settings_show = listfile2.read().splitlines()

    return cfg, settings_show


def get_subfolder_seq(dataset, split):
    """
    Returns the appropriate subfolder and dataset configurations based on the dataset 
    (e.g., KITTI or nuScenes) and split type (train, val, or test).
    """
    file_path = os.path.dirname(os.path.realpath(__file__))
    if dataset == 'KITTI':
        det_id2str = {1: 'Pedestrian', 2: 'Car', 3: 'Cyclist'}
        subfolder = {'train': 'training', 'val': 'training', 'test': 'testing'}[split]
        hw = {'image': (375, 1242), 'lidar': (720, 1920)}
        seq_eval = {'train': ['0000', '0002', '0003', '0004', '0005', '0007', '0009', '0011', '0017', '0020'], 'val': ['0001', '0006', '0008', '0010', '0012', '0013', '0014', '0015', '0016', '0018', '0019'], 'test': ['%04d' % i for i in range(29)]}[split]
        data_root = os.path.join(file_path, 'data/KITTI')

    elif dataset == 'nuScenes':
        det_id2str = {1: 'Pedestrian', 2: 'Car', 3: 'Bicycle'}
        subfolder = split
        hw = {'image': (900, 1600), 'lidar': (720, 1920)}
        seq_eval = get_split()[split]  # Retrieve the correct sequence based on split type
        data_root = os.path.join(file_path, '../data/nuScenes/nuKITTI')

    else:
        raise ValueError(f"Dataset {dataset} is not supported.")
    
    return subfolder, det_id2str, hw, seq_eval, data_root



def is_path_exists(path):
    """Returns True if the path exists, False otherwise."""
    return os.path.exists(path)

def fileparts(file_path):
    """Extract directory, filename, and file extension from a file path."""
    directory, filename = os.path.split(file_path)
    name, ext = os.path.splitext(filename)
    return directory, name, ext

def load_list_from_folder(folder_path, ext_filter=None, depth=1, recursive=False, sort=True, save_path=None, debug=True):

    folder_path = os.path.normpath(folder_path)  # Normalizing the path instead of using safe_path
    if debug: assert os.path.isdir(folder_path), 'Input folder path is not correct: %s' % folder_path
    if not os.path.exists(folder_path): 
        print(f'The input folder does not exist: {folder_path}')
        return [], 0
    if debug:
        assert isinstance(recursive, bool), f'recursive should be a logical variable: {recursive}'
        assert depth is None or (isinstance(depth, int) and depth >= 1), f'Input depth is not correct: {depth}'
        assert ext_filter is None or (isinstance(ext_filter, list) and all(isinstance(ext_tmp, str) for ext_tmp in ext_filter)) or isinstance(ext_filter, str), 'Extension filter is not correct'
    
    if isinstance(ext_filter, str): 
        ext_filter = [ext_filter]  # Convert to a list if it's a string

    fulllist = list()
    if depth is None:        # Find all files recursively
        wildcard_prefix = '**' if recursive else '*'
        if ext_filter is not None:
            for ext_tmp in ext_filter:
                wildcard = os.path.join(wildcard_prefix, '*' + ext_tmp)
                curlist = glob.glob(os.path.join(folder_path, wildcard), recursive=True)
                if sort: curlist = sorted(curlist)
                fulllist += curlist
        else:
            wildcard = wildcard_prefix
            curlist = glob.glob(os.path.join(folder_path, wildcard), recursive=True)
            if sort: curlist = sorted(curlist)
            fulllist += curlist
    else:                    # Find files based on depth and recursive flag
        wildcard_prefix = '*'
        for index in range(depth-1): wildcard_prefix = os.path.join(wildcard_prefix, '*')
        if ext_filter is not None:
            for ext_tmp in ext_filter:
                wildcard = wildcard_prefix + ext_tmp
                curlist = glob.glob(os.path.join(folder_path, wildcard))
                if sort: curlist = sorted(curlist)
                fulllist += curlist
        else:
            wildcard = wildcard_prefix
            curlist = glob.glob(os.path.join(folder_path, wildcard))
            if sort: curlist = sorted(curlist)
            fulllist += curlist
        if recursive and depth > 1:
            newlist, _ = load_list_from_folder(folder_path=folder_path, ext_filter=ext_filter, depth=depth-1, recursive=True)
            fulllist += newlist

    fulllist = [os.path.normpath(path_tmp) for path_tmp in fulllist]
    num_elem = len(fulllist)

    # Save list to a path if specified
    if save_path is not None:
        save_path = os.path.normpath(save_path)
        with open(save_path, 'w') as file:
            for item in fulllist:
                file.write(f'{item}\n')

    return fulllist, num_elem



# Define essential paths and directories for loading data
def initialize(cfg: Any, data_root: str, save_dir: str, subfolder: str, seq_name: str, 
               cat: str, ID_start: int, hw: Tuple[int, int], log_file: Any, dd: List[float]) -> Tuple:
    """
    Initializes the tracker and paths for required data
    """
    oxts_dir = os.path.join(data_root, subfolder, 'oxts')
    calib_dir = os.path.join(data_root, subfolder, 'calib')
    image_dir = os.path.join(data_root, subfolder, 'image_02')

    # Load ego poses (OXT file)
    oxts_file = os.path.join(data_root, subfolder, 'oxts', f'{seq_name}.json')
    if not is_path_exists(oxts_file): 
        oxts_file = os.path.join(data_root, 'oxts', subfolder, f'{seq_name}.txt')
    
    imu_poses = load_oxts(oxts_file)  # Seq frames x 4 x 4

    # Load calibration files
    calib_file = os.path.join(data_root, 'calib', subfolder, f'{seq_name}.txt')
    calib = Calibration(calib_file)

    # Image path for visualization
    img_seq = os.path.join(data_root, 'image', subfolder, 'image_02', seq_name)

    # Initialize tracker with relevant data
    tracker = CAMETRACK(cfg, cat, calib=calib, oxts=imu_poses, img_dir=img_seq, hw=hw, 
                       log=log_file, ID_init=ID_start, dd=dd)

    # Compute the min/max frame range for the sequence
    frame_list, _ = load_list_from_folder(img_seq)
    frame_list = [fileparts(frame_file)[1] for frame_file in frame_list]

    return tracker, frame_list

# Function to generate a formatted timestamp
def get_timestring() -> str:
    """
    Returns a formatted string of the current time for logging
    """
    return time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())

# Logging utility to print and log messages
def print_log(message: str, log_file: Any = None, display: bool = True) -> None:
    """
    Prints and optionally writes messages to a log file
    """
    if log_file:
        log_file.write(message + '\n')
    
    if display:
        print(message)

# Ensure directory exists, otherwise create it
def mkdir_if_missing(directory: str) -> None:
    """
    Creates directory if it doesn't exist
    """
    if not os.path.exists(directory):
        os.makedirs(directory)



# Main function for processing tracking per category
def main_per_cat(cfg: Any, cat: str, log: Any, ID_start: int, dd: List[float], PC: int) -> int:
    """
    Run tracking for a specific category and log the results
    """
    result_sha = f'{cfg.det_name}_{cfg.split}'
    det_root = os.path.join('./data', cfg.dataset, 'detection', f'{cfg.det_name}_{cat}_{cfg.split}')
    subfolder, det_id2str, hw, seq_eval, data_root = get_subfolder_seq(cfg.dataset, cfg.split)
    save_dir = os.path.join(cfg.save_root, result_sha + '_result')

    mkdir_if_missing(save_dir)

    # Create evaluation directories
    eval_dir_dict = {0: os.path.join(save_dir, 'data')}
    mkdir_if_missing(eval_dir_dict[0])

    # Process each sequence
    seq_count = 0
    total_time, total_frames = 0.0, 0
    for seq_name in seq_eval:
        seq_file = os.path.join(det_root, f'{seq_name}.txt')
        seq_dets, flag = load_detection_data(seq_file)

        if not flag: continue  # Skip if no detection data available

        # Prepare directories for saving results
        eval_file_dict = generate_saving_directory(eval_dir_dict, seq_name, save_dir)

        # Initialize the tracker
        tracker, frame_list = initialize(cfg, data_root, save_dir, subfolder, seq_name, cat, ID_start, hw, log, dd)

        # Loop over the frames in the sequence
        min_frame, max_frame = int(frame_list[0]), int(frame_list[-1])
        for frame in range(min_frame, max_frame + 1):
            print_str = f'Processing {result_sha} {seq_name}: {seq_count}/{len(seq_eval)}, {frame}/{max_frame}   \r'
            sys.stdout.write(print_str)
            sys.stdout.flush()

            # Track the detections for the current frame
            dets_frame = retrieve_frame_detections(seq_dets, frame, PC)
            
            #print("dets_frame:",dets_frame)
            start_time = time.time()
            #print(seq_dets)
            results, affi = tracker.track(dets_frame, frame, seq_name)
            total_time += time.time() - start_time
            
            

            # Save the results
            for result_tmp in results[0]:  # N x 15
                save_results(result_tmp, eval_file_dict[0], det_id2str, frame, cfg.score_threshold, dd, seq_name)

            total_frames += 1
        seq_count += 1

        eval_file_dict[0].close()
        ID_start = max(ID_start, tracker.ID_count[0])
    print_log(f'{cfg.dataset}, {result_sha}: {total_time:.1f} seconds for {total_frames} frames or {total_frames / total_time:.1f} FPS', log, display=True)

    return ID_start

# Main entry point for the script
def main(args: Any) -> None:
    """
    Main function for running the tracking pipeline
    """
    # Load configuration files
    config_path = f'./configs/{args.dataset}.yml'
    cfg, settings_show = Config(config_path)

    # Overwrite configurations if needed
    if args.split != '': cfg.split = args.split
    if args.IOU_module != '': cfg.IOU_module = args.IOU_module

    # Filter categories based on the provided argument
    if args.category.lower() != 'all':
        cfg.cat_list = [cat for cat in cfg.cat_list if cat.lower() == args.category.lower()]
        if not cfg.cat_list:
            print(f"Category '{args.category}' not found in the dataset.")
            return

    # Log the configurations used
    time_str = get_timestring()
    log_path = os.path.join(cfg.save_root, f'log/log_{time_str}_{cfg.dataset}_{cfg.split}.txt')
    mkdir_if_missing(os.path.join(cfg.save_root, 'log'))
    log = open(log_path, 'w')
    for data in settings_show:
        print_log(data, log, display=False)

    # Global ID counter initialization
    ID_start = 1

    # Run tracking for each category
    for cat in cfg.cat_list:
        #print(cfg,cat)
        ID_start = main_per_cat(cfg, cat, log, ID_start, args.para, args.PC)


    print_log('\nDone!', log, display=True)
    log.close()

# Entry point of the script
if __name__ == '__main__':
    args = parse_args()
    main(args)

